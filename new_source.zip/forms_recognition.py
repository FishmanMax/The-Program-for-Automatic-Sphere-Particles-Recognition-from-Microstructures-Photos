# Импорт библиотек
import numpy as np
import cv2
import os.path
import math
import areas_math as am

# Функция для поиска частиц


def find_all(find_circles, find_elipses, find_amorphous, find_squares, scale):
    # Проверяем есть ли отфильтрованное изображение
    if os.path.exists('tmp//filter_image.jpg'):
        img = cv2.imread('tmp//filter_image.jpg', cv2.IMREAD_COLOR)  # Чтение изображения
    else:
        img = cv2.imread('tmp//load_image.jpg', cv2.IMREAD_COLOR)  # Чтение изображения

    no_filter_img = cv2.imread('tmp//load_image.jpg')  # Открываем нефильтрованное изображение

    circles_count = 0  # Кол-во найденных круглых частиц
    ellipses_count = 0  # Кол-во найденных эллипсоидных частиц
    triangles_count = 0  # Кол-во найденных треугольных частиц
    squares_count = 0  # Кол-во найденных квадратных частиц
    pentagon_count = 0  # Кол-во найденных пятиугольных частиц
    hexagonal_count = 0  # Кол-во найденных шестиугольных частиц
    heptagon_count = 0  # Кол-во найденных семиугольных частиц
    octagon_count = 0  # Кол-во найденных восьмиугольных частиц
    nonagon_count = 0  # Кол-во найденных девятиугольных частиц
    decagon_count = 0  # Кол-во найденных десятиугольных частиц
    other_count = 0  # Кол-во остальных найденных частиц

    circles_areas = []  # Список площадей круглых частиц
    circles_diameters = []  # Список диаметров круглых частиц

    elipses_areas = []  # Список площадей эллипсоидных частиц
    elipses_diameters = []  # Список диаметров эллипсоидных частиц

    triangles_areas = []  # Список площадей треугольных частиц
    squares_areas = []  # Список площадей квадратных частиц
    pentagon_areas = []  # Список площадей пятиугольных форм
    hexagonal_areas = []  # Список площадей шестиугольных форм
    heptagon_areas = []  # Список площадей семиугольных форм
    octagon_areas = []  # Список площадей восьмиугольных форм
    nonagon_areas = []  # Список площадей девятиугольных форм
    decagon_areas = []  # Список площадей десятиугольных форм
    other_areas = []  # Список площадей остальных частиц

    # Если нужно найти круглые частицы

    if find_circles:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Конвертация в чёрно-белый цвет

        gray_blurred = cv2.blur(gray, (3, 3))  # Размытие изображения

        param1 = 50
        param2 = 30
        minRadius = 10  # Минимальный радиус частицы
        maxRadius = 100  # Максимальный радиус частицы

        detected_circles = cv2.HoughCircles(gray_blurred, cv2.HOUGH_GRADIENT, 1, 30, param1=param1,
                                            param2=param2, minRadius=minRadius,
                                            maxRadius=maxRadius)  # Ищем круги на изображении через преобразование хафа

        # Если круги найдены
        if detected_circles is not None:
            detected_circles = np.uint16(np.around(detected_circles))  # Конвертируем параметры в uint16

            for pt in detected_circles[0, :]:
                a, b, r = pt[0], pt[1], pt[2]

                area = math.pi * (r*r)  # Получаем площадь круга через радиус
                area = area * scale  # Умножаем площадь круга на масштаб изображения
                diameter = (2 * r) * scale  # Получаем диаметр круга через радиус. Умножаем его на масштаб изображения
                circles_areas.append(round(area, 2))  # Добавляем площадь круга в список
                circles_diameters.append(round(diameter, 2))  # Добавляем диаметр круга в список

                # Отмечаем круги на изображении
                cv2.circle(img, (a, b), r, (255, 0, 0), 2)
                cv2.circle(no_filter_img, (a, b), r, (255, 0, 0), 2)

        circles_count = len(str(detected_circles).split("\n"))  # Добавляем полученное кол-во кругов к счётчику

    # Если нужно найти квадраты

    if find_squares:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Конвертация в чёрно-белый цвет

        # Фильтрация изображения
        ret, thresh = cv2.threshold(gray, 50, 255, 0)  # Фильтрация изображения
        contours, hierarchy = cv2.findContours(thresh, 1, 2)  # Находим контуры

        # Отмечаем формы на фото
        for cnt in contours:
            approx = cv2.approxPolyDP(cnt, 0.01 * cv2.arcLength(cnt, True), True)  # Аппроксимация контуров
            if len(approx) == 4:  # Если длина списка равна 4
                x, y, w, h = cv2.boundingRect(cnt)  # Получаем длину и высоту
                ratio = float(w) / h  # Получаем соотношение сторон
                if ratio >= 0.9 and ratio <= 1.1:  # Если это квадрат
                    square = (w * h) * scale  # Получаем площадь. Умножаем её на масштаб
                    squares_areas.append(round(square, 2))  # Добавляем площадь в список
                    squares_count += 1  # Добавляем квадрат к счётчику

                    img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отмечаем квадрат на изображении
                    no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отмечаем квадрат на изображении

    if find_elipses:  # Если нужно найти эллипсы
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Переводим изображение в чёрно-белый формат

        ret, thresh = cv2.threshold(gray, 150, 255, 0)  # Фильтруем изображение

        contours, hierarchy = cv2.findContours(thresh.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # Ищем контуры

        for cnt in contours:  # Цикл для обработки контуров
            try:
                approx = cv2.approxPolyDP(cnt, 0.01 * cv2.arcLength(cnt, True), True)
                if len(approx) <= 12:
                    if len(approx) == 4:  # Если у фигуры 4 угла. Пропускаем
                        continue
                    elif len(approx) == 3:  # Если у фигуры 3 угла. Пропускаем
                        continue
                    elif len(approx) == 5:  # Если у фигуры 5 углов. Пропускаем
                        continue
                    elif len(approx) == 6:  # Если у фигуры 6 углов. Пропускаем
                        continue
                    elif len(approx) == 8: # Если у фигуры 8 углов. Пропускаем
                        continue
                    if cv2.isContourConvex(approx):
                        ellipses_count += 1  # Добавляем единицу к счётчику эллипсоидных частиц
                        ellipse = cv2.fitEllipse(cnt)
                        orig_x, orig_y, width, height = cv2.boundingRect(cnt)

                        area = (math.pi * ((width * height) / 4)) * scale  # Получаем площадь фигуры
                        diameter = width * scale  # Получаем диаметр фигуры
                        elipses_areas.append(round(area, 2))  # Добавляем площадь в список
                        elipses_diameters.append(round(diameter, 2))  # Добавляем диаметр в список

                        cv2.ellipse(img, ellipse, (255, 0, 0), 3)  # Отмечаем фигуру на изображении
                        cv2.ellipse(no_filter_img, ellipse, (255, 0, 0), 3)  # Отмечаем фигуру на изображении
            except cv2.error:
                pass

    if find_amorphous:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Конвертируем изображение в чёрно-белый цвет
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]  # Фильтруем изображение
        
        # Находим контуры
        cnts = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = cnts[0] if len(cnts) == 2 else cnts[1]

        for cnt in cnts:
            approx = cv2.approxPolyDP(cnt, 0.01 * cv2.arcLength(cnt, True), True)  # Аппроксимация контуров
            if len(approx) == 3:  # Если это треугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем его на масштаб. Округляем
                area = am.triangle_square(perimeter)  # Получаем площадь
                triangles_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                triangles_count += 1  # Добавляем единицу к счётчику треугольников
            elif len(approx) == 4:  # Если это четырёхугольник
                x, y, w, h = cv2.boundingRect(cnt)  # Получаем длину и высоту
                ratio = float(w) / h  # Получаем соотношение сторон
                if ratio >= 0.9 and ratio <= 1.1:
                    pass  # Если это квадрат, ничего не делаем
                else:
                    area = (w * h) * scale  # Получаем площадь. Умножаем её на масштаб
                    squares_areas.append(area)  # Добавляем площадь в список
                    img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                    no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                    squares_count += 1  # Добавляем единицу к счётчику
            elif len(approx) == 5:  # Если это пятиугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.pentagon_area(perimeter)  # Получаем площадь
                pentagon_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                pentagon_count += 1  # Добавляем единицу к счётчику
            elif len(approx) == 6:  # Если это шестиугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.hexagonal_area(perimeter)  # Получаем площадь
                hexagonal_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                hexagonal_count += 1  # Добавляем единицу к счётчику
            elif len(approx) == 7:  # Если это семиугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.heptagon_area(perimeter)  # Получаем площадь
                heptagon_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                heptagon_count += 1  # Добавляем единицу к счётчику
            elif len(approx) == 8:  # Если это восьмиугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.octagon_area(perimeter)  # Получаем площадь
                octagon_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                octagon_count += 1  # Добавляем единицу к счётчику
            elif len(approx) == 9:  # Если это девятиугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.nonagon_area(perimeter)  # Получаем площадь
                nonagon_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                nonagon_count += 1  # Добавляем единицу к счётчику
            elif len(approx) == 10:  # Если это десятиугольник
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.decagon_area(perimeter)  # Получаем площадь
                decagon_areas.append(area)  # Добавляем площадь в список
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отрисовываем контуры на изображении без фильтра
                decagon_count += 1  # Добавляем единицу к счётчику
            else:
                if cv2.isContourConvex(approx):  # Проверяем является частица выпуклой, если да, пропускаем итерацию
                    continue
                img = cv2.drawContours(img, [cnt], -1, (255, 0, 0), 2)  # Иначе отмечаем контуры на изображении
                no_filter_img = cv2.drawContours(no_filter_img, [cnt], -1, (255, 0, 0), 2)  # Отмечаем контуры на изображении без фильтра
                perimeter = cv2.arcLength(cnt, True)  # Получаем периметр
                perimeter = round(perimeter * scale, 2)  # Умножаем периметр на масштаб. Округляем
                area = am.other_area(perimeter, len(approx))  # Получаем площадь
                other_areas.append(round(area, 2))  # Добавляем площадь в список
                other_count += 1  # Добавляем единицу к счётчику

    cv2.imwrite("tmp//out_image.jpg", img)  # Сохраняем отфильтрованное изображение
    cv2.imwrite("tmp//no_filter_out_image.jpg", no_filter_img)  # Сохраняем отфильтрованное изображение

    return circles_count, triangles_count, squares_count, pentagon_count,\
        hexagonal_count, heptagon_count, octagon_count, nonagon_count,\
        decagon_count, ellipses_count, other_count, circles_areas, circles_diameters, \
        elipses_areas, elipses_diameters, triangles_areas, squares_areas, \
        pentagon_areas, hexagonal_areas, heptagon_areas, octagon_areas, \
        nonagon_areas, decagon_areas, other_areas
