# Импорт библиотек
import os
import cv2
import numpy as np
from PIL import ImageColor


'''Функция для очистки папки с временными файлами'''


def clean_tmp():
    for file in os.listdir("tmp"):  # Цикл для прохода по всем файлам в папке
        os.remove(f"tmp//{file}")  # Удаляем файл


'''Функция для фильтрации изображения по цвету'''


def color_filter(min_color, max_color):
    img = cv2.imread('tmp//load_image.jpg')  # Открываем изображение

    min_color = ImageColor.getcolor(min_color, "RGB")  # Преобразовываем минимальное значение цвета из HEX в RGB
    max_color = ImageColor.getcolor(max_color, "RGB")  # Преобразовываем максимальное значение цвета из HEX в RGB

    hsv_min = np.array(min_color, np.uint8)  # Переводим значение в массив Numpy
    hsv_max = np.array(max_color, np.uint8)  # Переводим значение в массив Numpy

    thresh = cv2.inRange(img, hsv_min, hsv_max)  # Фильтруем изображение

    cv2.imwrite('tmp//filter_image.jpg', thresh)  # Сохраняем результат во временную папку
