import sys
from tkinter import messagebox
from tkinter import filedialog


def exit_app():  # Функция для выхода из приложения
    answer = messagebox.askokcancel(title="Вы уверены?",
                                    message="Вы уверены что хотите покинуть программу?")  # Спрашиваем уверен ли пользователь что хотет выйти
    
    # Если пользователь уверен, закрываем программу методом sys.exit
    if answer:
        sys.exit()


def load_photo():  # Функция для запуска диалогового окна при открытии изображения
    filetypes = (("Точечные рисунки", "*.bmp *.dib"),
                 ("JPEG", "*.jpg *.jpeg *jpe *.jfif"),
                 ("TIFF", "*.tif *.tiff"),
                 ("PNG", "*.png"))  # Кортеж с типами файлов

    filepath = filedialog.askopenfilename(defaultextension="*.bmp",
                                          filetypes=filetypes)  # Путь к файлу

    return filepath


def load_photo_err():  # Функция для вывода сообщения об ошибке при загрузке изображения
    messagebox.showerror(title="Ошибка!", message="Не удалось загрузить изображение!")
