# Импорт необходимых модулей
import math


# Функция для поиска плоащди треугольника


def triangle_square(perimeter):
    a = perimeter / 3  # Вычисляем длину каждой стороны треугольника путём разделения периметра на три части
    area = (3 ** 0.5) / 4 * a ** 2  # Вычисляем площадь треугольника с помощью формулы

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади четырёхугольника


def square_area(a, b, c, d):
    p = a + b + c + d  # Вычисляем периметр четырёхугольника
    s = p / 2  # Вычисляем полупериметр четырёхугольника
    area = (s - a) * (s - b) * (s - c) * (s - d)  # Вычисляем плоащадь через формулу Герона

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади пятиугольника


def pentagon_area(perimeter):
    side_length = perimeter / 5  # Получаем длину каждой стороны путём разделения периметра на 5
    apothem = side_length / (2 * math.tan(math.pi / 5))  # Получаем апофему с помощью формулы
    area = (5 * side_length * apothem) / 2  # Вычисляем площадь

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади шестиугольника


def hexagonal_area(perimeter):
    side_length = perimeter / 6  # Получаем сторону шестиугольника путём разделения периметра на 6
    apothem_length = side_length * 3**0.5 / 2  # Вычисляем апофему с помощью формулы
    area = apothem_length * perimeter / 2  # Вычисляем площадь

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади семиугольника


def heptagon_area(perimeter):
    side_length = perimeter / 7  # Получаем длину стороны путём разделения периметра на 7
    apothem_length = side_length / (2 * math.tan(math.pi / 7))  # Получаем апофему
    area = (1 / 2) * perimeter * apothem_length  # Вычисляем площадь

    return round(area, 2)  # Возвращем округлённое значение


# Функция для поиска площади восьмиугольника


def octagon_area(perimeter):
    side = perimeter / 8  # Получаем длину стороны путём разделения периметра на 8
    area = 2 * (1 + (2 ** 0.5)) * (side ** 2)  # Вычисляем площадь

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади девятиугольника


def nonagon_area(perimeter):
    side_length = perimeter / 9  # Получаем длину стороны путём разделения периметра на 9
    apothem_length = side_length / (2 * math.tan(math.pi / 9))  # Получаем апофему
    area = (9 * side_length * apothem_length) / 2  # Вычисляем площадь

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади десятиугольника


def decagon_area(perimeter):
    s = perimeter / 10  # Получаем длину стороны путём разделения периметра на 10
    area = (10 * s ** 2) / (4 * math.tan(math.pi / 10))  # Вычисляем площадь

    return round(area, 2)  # Возвращаем округлённое значение


# Функция для поиска площади других многоугольников


def other_area(perimeter, n_sides):  # Функция принимает два аргумента периметр и кол-во сторон
    side_length = perimeter / n_sides  # Получаем длину стороны путём разделения периметра на кол-во сторон
    apothem_length = side_length / (2 * math.tan(math.pi / n_sides))  # Вычисляем апофему
    area = (perimeter * apothem_length) / 2  # Вычисляем площадь

    return round(area, 2)  # Возвращаем округлённое значение
